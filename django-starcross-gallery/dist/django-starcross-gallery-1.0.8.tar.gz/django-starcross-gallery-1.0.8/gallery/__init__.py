
default_app_config = 'gallery.apps.GalleryConfig'